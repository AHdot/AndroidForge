package com.example.movieshadow

import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.Gravity
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale

data class SubtitleLine(val startMs: Long, val endMs: Long, val text: String)

@UnstableApi
class MainActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private var videoUri: Uri? = null
    private var lines: List<SubtitleLine> = emptyList()
    private var currentIndex = 0
    private var repeatLine = false
    private var showChinese = true
    private lateinit var root: LinearLayout
    private lateinit var playerView: PlayerView
    private lateinit var subtitleText: TextView
    private lateinit var statusText: TextView
    private lateinit var listView: ListView
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var repeatButton: Button
    private val uiHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val playbackTicker = object : Runnable {
        override fun run() {
            updateCurrentLine()
            uiHandler.postDelayed(this, 120)
        }
    }
    private val prefs by lazy { getSharedPreferences("movie_shadow", MODE_PRIVATE) }

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            videoUri = uri
            prefs.edit().putString("video_uri", uri.toString()).apply()
            startVideo(uri)
        }
    }
    private val pickSubtitle = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            loadSrt(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(16,21,29)
        window.navigationBarColor = android.graphics.Color.rgb(16,21,29)
        buildUi()
        val saved = prefs.getString("video_uri", null)
        if (saved != null) {
            try { startVideo(Uri.parse(saved)) } catch (_: Exception) {}
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun button(label: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        }
    }
    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(android.graphics.Color.rgb(16,21,29))
        }
        val title = TextView(this).apply {
            text = "电影跟读  ·  Movie Shadow"
            textSize = 21f; setTextColor(-1); gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, dp(10))
        }
        root.addView(title)
        val importRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        importRow.addView(button("选择电影") { pickVideo.launch(arrayOf("video/*")) }, LinearLayout.LayoutParams(0, dp(48), 1f))
        importRow.addView(button("导入 SRT 字幕") { pickSubtitle.launch(arrayOf("text/*", "application/octet-stream", "*/*")) }, LinearLayout.LayoutParams(0, dp(48), 1f))
        root.addView(importRow)
        playerView = PlayerView(this).apply {
            useController = true
            layoutParams = LinearLayout.LayoutParams(-1, dp(220))
        }
        root.addView(playerView)
        subtitleText = TextView(this).apply {
            text = "先选择电影，再导入对应的 .srt 字幕文件。"
            textSize = 19f; gravity = Gravity.CENTER
            setTextColor(-1); setPadding(dp(8), dp(12), dp(8), dp(12))
            setBackgroundColor(android.graphics.Color.rgb(31,39,51))
        }
        root.addView(subtitleText, LinearLayout.LayoutParams(-1, dp(100)))
        statusText = TextView(this).apply {
            text = "课程列表：导入字幕后自动生成"
            textSize = 13f; setTextColor(0xFFB8C4D3.toInt())
            setPadding(0, dp(6), 0, dp(4))
        }
        root.addView(statusText)
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        controls.addView(button("上一句") { jump(-1) }, LinearLayout.LayoutParams(0, dp(46), 1f))
        repeatButton = button("单句循环：关") { repeatLine = !repeatLine; repeatButton.text = if (repeatLine) "单句循环：开" else "单句循环：关" }
        controls.addView(repeatButton, LinearLayout.LayoutParams(0, dp(46), 1f))
        controls.addView(button("下一句") { jump(1) }, LinearLayout.LayoutParams(0, dp(46), 1f))
        root.addView(controls)
        val controls2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        controls2.addView(button("字幕：中英") { showChinese = !showChinese; updateSubtitle() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        controls2.addView(button("速度") { chooseSpeed() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        controls2.addView(button("定位当前句") { updateCurrentLine(force = true) }, LinearLayout.LayoutParams(0, dp(44), 1f))
        root.addView(controls2)
        listView = ListView(this).apply {
            divider = android.graphics.drawable.ColorDrawable(0xFF303A48.toInt())
            dividerHeight = dp(1)
            setBackgroundColor(android.graphics.Color.rgb(22,29,39))
        }
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf())
        listView.adapter = adapter
        listView.setOnItemClickListener { _, _, position, _ ->
            currentIndex = position
            player?.seekTo(lines[position].startMs)
            player?.play()
            updateSubtitle()
            listView.setSelection(position)
        }
        root.addView(listView, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        uiHandler.post(playbackTicker)
    }

    private fun startVideo(uri: Uri) {
        try {
            player?.release()
            player = ExoPlayer.Builder(this).build().also { exo ->
                playerView.player = exo
                exo.setMediaItem(MediaItem.fromUri(uri))
                exo.prepare()
                exo.playWhenReady = false
                exo.addListener(object : Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) { updateCurrentLine(force = true) }
                    override fun onPlaybackStateChanged(playbackState: Int) { updateCurrentLine(force = true) }
                })
            }
            statusText.text = "电影已载入。请导入同一部电影的 SRT 字幕。"
        } catch (e: Exception) {
            statusText.text = "无法打开该视频：${e.message ?: "格式可能不受支持"}"
        }
    }

    private fun loadSrt(uri: Uri) {
        try {
            val input = contentResolver.openInputStream(uri) ?: throw Exception("无法读取字幕文件")
            val text = BufferedReader(InputStreamReader(input, Charsets.UTF_8)).use { it.readText() }
            lines = parseSrt(text)
            currentIndex = 0
            adapter.clear()
            adapter.addAll(lines.mapIndexed { i, line -> "${i + 1}. ${formatTime(line.startMs)}  ${line.text.replace("\n", " / ")}" })
            adapter.notifyDataSetChanged()
            statusText.text = "已生成 ${lines.size} 句课程。点击任意句子即可跳转播放。"
            updateSubtitle()
        } catch (e: Exception) {
            statusText.text = "字幕读取失败，请选择 .srt 文件（UTF-8 编码更稳妥）。"
        }
    }

    private fun parseSrt(raw: String): List<SubtitleLine> {
        val normalized = raw.removePrefix("\uFEFF").replace("\r\n", "\n").replace("\r", "\n")
        val blocks = normalized.split(Regex("\n\\s*\n"))
        val result = mutableListOf<SubtitleLine>()
        val timeRegex = Regex("(\\d{2}):(\\d{2}):(\\d{2})[,\\.](\\d{1,3})\\s*-->\\s*(\\d{2}):(\\d{2}):(\\d{2})[,\\.](\\d{1,3})")
        for (block in blocks) {
            val rows = block.lines()
            val ti = rows.indexOfFirst { timeRegex.containsMatchIn(it) }
            if (ti < 0) continue
            val match = timeRegex.find(rows[ti]) ?: continue
            fun millis(h: String, m: String, s: String, ms: String): Long {
                val padded = ms.padEnd(3, '0').take(3).toLong()
                return (((h.toLong() * 60 + m.toLong()) * 60 + s.toLong()) * 1000) + padded
            }
            val start = millis(match.groupValues[1], match.groupValues[2], match.groupValues[3], match.groupValues[4])
            val end = millis(match.groupValues[5], match.groupValues[6], match.groupValues[7], match.groupValues[8])
            val caption = rows.drop(ti + 1).joinToString("\n").trim()
                .replace(Regex("<[^>]*>"), "").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
            if (caption.isNotBlank() && end > start) result.add(SubtitleLine(start, end, caption))
        }
        return result
    }

    private fun jump(delta: Int) {
        if (lines.isEmpty()) { statusText.text = "请先导入 SRT 字幕。"; return }
        currentIndex = (currentIndex + delta).coerceIn(0, lines.lastIndex)
        player?.seekTo(lines[currentIndex].startMs)
        player?.play()
        updateSubtitle()
        listView.setSelection(currentIndex)
    }

    private fun updateCurrentLine(force: Boolean = false) {
        val p = player?.currentPosition ?: return
        if (lines.isEmpty()) return
        val found = lines.indexOfLast { p >= it.startMs && p < it.endMs }
        if (found >= 0 && (force || found != currentIndex)) {
            currentIndex = found
            updateSubtitle()
            listView.setSelection(found)
        }
        if (repeatLine && found >= 0 && p >= lines[found].endMs - 80) {
            player?.seekTo(lines[found].startMs)
        }
    }

    private fun updateSubtitle() {
        if (lines.isEmpty() || currentIndex !in lines.indices) return
        subtitleText.text = lines[currentIndex].text
        statusText.text = "第 ${currentIndex + 1} / ${lines.size} 句  ·  ${formatTime(lines[currentIndex].startMs)}"
    }

    private fun chooseSpeed() {
        val speeds = arrayOf("0.6x", "0.75x", "0.9x", "1.0x", "1.1x")
        android.app.AlertDialog.Builder(this).setTitle("播放速度")
            .setItems(speeds) { _, which ->
                val speed = speeds[which].dropLast(1).toFloatOrNull() ?: 1f
                player?.setPlaybackSpeed(speed)
            }.show()
    }

    private fun formatTime(ms: Long): String {
        val total = ms / 1000
        return String.format(Locale.US, "%02d:%02d:%02d", total / 3600, (total / 60) % 60, total % 60)
    }

    override fun onStop() {
        super.onStop()
        player?.let { prefs.edit().putLong("position", it.currentPosition).apply() }
    }
    override fun onDestroy() {
        uiHandler.removeCallbacks(playbackTicker)
        player?.release()
        player = null
        super.onDestroy()
    }
}
