# 电影跟读 Movie Shadow（Android 源码项目）

这是一个不需要 AI API、不需要账号和服务器的 Android Studio 项目。

## 已实现
- 从手机文件选择器选择本地视频
- 导入 SRT 字幕，自动解析成逐句课程
- 点击字幕句子跳转到视频对应时间
- 上一句 / 下一句、单句循环、播放速度选择
- 保存最近打开的视频 URI（设备允许持久授权时）

## 当前限制
- 这是可编译的 Android Studio 源码项目，不是已签名 APK。
- 当前版本需要单独的 `.srt` 字幕文件；不会自动识别画面硬字幕，也不会自动生成字幕。
- 中英双语显示取决于 SRT 本身是否含双语行；当前版本不做机器翻译。
- 需安装 Android Studio，并让 Gradle 下载依赖后构建 APK。
- 视频编码兼容性由 Android/Media3 解码器决定。

## 构建 APK
1. 在 Windows 电脑安装 Android Studio（建议稳定版）。
2. 解压本项目 ZIP。
3. Android Studio 选择 **Open**，打开解压后的 `MovieShadowAndroid` 文件夹。
4. 等待 Gradle Sync 完成。
5. 菜单选择 **Build > Build Bundle(s) / APK(s) > Build APK(s)**。
6. APK 通常位于 `app/build/outputs/apk/debug/app-debug.apk`。
7. 将 APK 复制到安卓手机安装；如果系统询问，允许该文件管理器安装未知来源应用。

如果 Gradle 提示 SDK 未安装，在 Android Studio 的 SDK Manager 安装 Android SDK Platform 35 和对应 Build Tools。

## 使用
1. 打开 APP，点“选择电影”选手机中的视频。
2. 点“导入 SRT 字幕”，选这部电影对应的 `.srt` 文件。
3. 等待出现课程列表，点击任意句子跳转。
4. 点“单句循环：关”可切换循环；“速度”可以慢速播放。
